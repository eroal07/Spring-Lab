package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Employee;
import com.cg.ioc.Sbu;

public class EmployeeTest {

	@Test
	public void testEmployee() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		
		Sbu sbu= (Sbu) ctx.getBean("sbubean");
		/*System.out.println("Sbu Details");
		System.out.println("---------------------");
		System.out.println(sbu);
		
		System.out.println("Employee Details:------------------");
		System.out.println(emp +""+ "\n"+ emp2);*/
		
		System.out.println(sbu);
	
	}

}
