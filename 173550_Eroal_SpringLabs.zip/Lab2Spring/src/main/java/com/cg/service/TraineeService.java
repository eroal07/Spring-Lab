package com.cg.service;

import java.util.List;

import com.cg.ctr.Trainee;

public interface TraineeService {

	void saveTrainee(Trainee a);
	
	Trainee getTrainee(int traineeId);
	
	void deleteTrainee(Trainee a);
	
	void updateTrainee(Trainee a);
	
	List<Trainee> getAllTrainee();
	
}
