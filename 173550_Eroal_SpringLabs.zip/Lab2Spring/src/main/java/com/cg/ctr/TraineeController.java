package com.cg.ctr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;

	@RequestMapping(value = "/")
	public String home(Model m) {
		m.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(Login log) {

		// Logic to validate userName and password against database
		if (log.getUserName().equals("admin") && log.getPassword().equals("123456")) {
			return "loginSuccess";
		} else {
			return "login";
		}
	}

	@RequestMapping(value = "/Add")
	public String addTrainee(Model m) {
		m.addAttribute("trainee", new Trainee());
		return "AddTrainee";

	}

	@RequestMapping(path = "/saveDetails")
	public String dataAdd(@ModelAttribute("trainee") Trainee trainee, Model m) {
		System.out.println(trainee);
		service.saveTrainee(trainee);

		return "loginSuccess";

	}

	@RequestMapping(value = "/Delete")
	public String deleteTrainee(Model model) {
		return "DeleteTrainee";
	}

	@RequestMapping(value = "/find")
	public String retrieveDetails(Model m, @RequestParam("id") int id) {

		Trainee trainee = service.getTrainee(id);
		m.addAttribute("trainee", trainee);
		return "DeleteTrainee";
	}

	@RequestMapping(value = "/deleteTrainee")
	public String deleteDetails(Model m, Trainee trainee) {
		service.deleteTrainee(trainee);
		m.addAttribute("trainee", trainee);

		return "loginSuccess";
	}
	
	@RequestMapping(value = "/retrive")
	public String findTrainee(Model model) {
		return "RetriveTrainee";
	}

	@RequestMapping(value = "/retriveTrainee")
	public String findDetails(Model m, @RequestParam("id") int id) {

		Trainee trainee = service.getTrainee(id);
		m.addAttribute("trainee", trainee);
		return "loginSuccess";
	}
	
	@RequestMapping(value="/getalltrainee")
	public String retrieveAllTrainee(Model m) {
		 List<Trainee> allTrainee =  service.getAllTrainee();
		 m.addAttribute("allTrainee", allTrainee);			
		return "Retrivetrainees";
		
	}
	
	@RequestMapping("/retriveall")
	public String gotomenu(Model m) {
		return "loginSuccess";
	}
	
	@RequestMapping(value = "/find")
	public String findDetail(Model m, @RequestParam("id") int id) {

		Trainee trainee = service.getTrainee(id);
		m.addAttribute("trainee", trainee);
		return "ModifyTrainee";
	}

	@RequestMapping("/updateTrainee")
	public String updateTraineeDetails(@ModelAttribute("updateTrainee") Trainee modifyTrainee, Model model) {
	 service.updateTrainee(modifyTrainee);
	 return "loginSuccess";
	}
	@RequestMapping("update")
	public String update(Model model) {
	 model.addAttribute("modifyTrainee", new Trainee());
	 return "ModifyTrainee";
	}
}
