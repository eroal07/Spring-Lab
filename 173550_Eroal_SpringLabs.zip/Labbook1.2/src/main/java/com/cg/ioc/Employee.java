package com.cg.ioc;

public class Employee {

	private int empId;
	private String empName;
	private int empSal;
	private String empBU;
	private int empAge;
	Sbu sbu=new Sbu();

	public Sbu getSbu() {
		return sbu;
	}

	public void setSbu(Sbu sbu) {
		this.sbu = sbu;
	}

	public Employee() {
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getEmpBU() {
		return empBU;
	}

	public void setEmpBU(String empBU) {
		this.empBU = empBU;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empBU=" + empBU
				+ ", empAge=" + empAge + "\n sbu=" + sbu + "]";
	}

	
}
