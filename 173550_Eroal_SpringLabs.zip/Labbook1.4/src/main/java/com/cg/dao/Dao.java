package com.cg.dao;

import com.cg.entity.Employee;

public interface Dao {
 
	public void addAll();
	public Employee findEmp(int id);

}
