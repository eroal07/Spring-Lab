package com.cg.main;

import java.util.Scanner;

import com.cg.dao.Dao;
import com.cg.dao.DaoImpl;
import com.cg.entity.Employee;

public class EmpMain {
	public static void main(String[] args) {

		Scanner scan= new Scanner(System.in);
		System.out.println("Enter Employee id to be found: ");
		int id = scan.nextInt();
		Dao dao = new DaoImpl();
		dao.addAll();
		
		Employee thisEmp =dao.findEmp(id);
		System.out.println(thisEmp);
		
		
	}

}
